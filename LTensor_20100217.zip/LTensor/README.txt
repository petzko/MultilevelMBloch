//////////////////////
	LTensor
/////////////////////

The file main.cpp includes a very brief introduction to LTensor sintaxis and features. For more information refer to the documentation and/or LTensor paper available on http://code.google.com/p/ltensor .