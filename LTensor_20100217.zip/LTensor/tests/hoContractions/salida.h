i j k | k 
i k j | k 
k i j | k 
