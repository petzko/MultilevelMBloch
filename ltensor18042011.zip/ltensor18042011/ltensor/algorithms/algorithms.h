
#ifndef ALGORITHM_H
#define ALGORITHM_J

#define Marray<T,1,base> Marray1


template <class T,class base>
Marray1 newtonRaphsonFNewmark(void (*funcArr() ),Marray1 &){







    }





#endif
